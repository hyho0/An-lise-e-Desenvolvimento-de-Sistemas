module com.example.cadastros_atv1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.cadastros_atv1 to javafx.fxml;
    exports com.example.cadastros_atv1;
}